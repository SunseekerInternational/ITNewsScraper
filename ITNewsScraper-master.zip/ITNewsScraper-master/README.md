# ITNewsScraper
News scraper, pulls from reddit API + RSI feeds
